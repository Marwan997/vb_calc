﻿Public Class Form1

    Dim display As String


    Private Sub zero_Click_1(sender As Object, e As EventArgs) Handles zero.Click
        Me.display_label.Text = Me.display_label.Text + "0"
    End Sub

    Private Sub point_Click(sender As Object, e As EventArgs) Handles point.Click
        Me.display_label.Text = Me.display_label.Text + "."
    End Sub

    Private Sub one_Click(sender As Object, e As EventArgs) Handles one.Click
        Me.display_label.Text = Me.display_label.Text + "1"
    End Sub

    Private Sub two_Click(sender As Object, e As EventArgs) Handles two.Click
        Me.display_label.Text = Me.display_label.Text + "2"
    End Sub

    Private Sub three_Click(sender As Object, e As EventArgs) Handles three.Click
        Me.display_label.Text = Me.display_label.Text + "3"
    End Sub

    Private Sub four_Click(sender As Object, e As EventArgs) Handles four.Click
        Me.display_label.Text = Me.display_label.Text + "4"
    End Sub

    Private Sub five_Click(sender As Object, e As EventArgs) Handles five.Click
        Me.display_label.Text = Me.display_label.Text + "5"
    End Sub

    Private Sub six_Click(sender As Object, e As EventArgs) Handles six.Click
        Me.display_label.Text = Me.display_label.Text + "6"
    End Sub

    Private Sub seven_Click(sender As Object, e As EventArgs) Handles seven.Click
        Me.display_label.Text = Me.display_label.Text + "7"
    End Sub

    Private Sub eight_Click(sender As Object, e As EventArgs) Handles eight.Click
        Me.display_label.Text = Me.display_label.Text + "8"
    End Sub

    Private Sub nine_Click(sender As Object, e As EventArgs) Handles nine.Click
        Me.display_label.Text = Me.display_label.Text + "9"
    End Sub

    Private Sub clear_Click(sender As Object, e As EventArgs) Handles clear.Click
        Me.display_label.ResetText()
        Me.operator_label.ResetText()

    End Sub

    Private Sub multiply_Click(sender As Object, e As EventArgs) Handles multiply.Click
        Me.operator_label.Text = "X"
        Me.num1_label.Text = Me.display_label.Text
        Me.display_label.ResetText()
    End Sub

    Private Sub minus_Click(sender As Object, e As EventArgs) Handles minus.Click
        Me.operator_label.Text = "-"
        Me.num1_label.Text = Me.display_label.Text
        Me.display_label.ResetText()
    End Sub

    Private Sub plus_Click(sender As Object, e As EventArgs) Handles plus.Click
        Me.operator_label.Text = "+"
        Me.num1_label.Text = Me.display_label.Text
        Me.display_label.ResetText()
    End Sub

    Private Sub divide_Click(sender As Object, e As EventArgs) Handles divide.Click
        Me.operator_label.Text = "/"
        Me.num1_label.Text = Me.display_label.Text
        Me.display_label.ResetText()
    End Sub

    Private Sub equal_Click(sender As Object, e As EventArgs) Handles equal.Click
        Dim num1 As Double
        Dim num2 As Double
        Dim operatorC As String

        num1 = Me.num1_label.Text
        num2 = Me.display_label.Text
        operatorC = Me.operator_label.Text


        If (operatorC = "+") Then
            Me.equal_label.Text = num1 + num2
        End If
        If (operatorC = "-") Then
            Me.equal_label.Text = num1 - num2
        End If
        If (operatorC = "X") Then
            Me.equal_label.Text = num1 * num2
        End If
        If (operatorC = "") Then
            Me.equal_label.Text = num1 / num2
        End If

        Me.operator_label.ResetText()
        Me.num1_label.ResetText()
        Me.display_label.ResetText()
    End Sub

    Private Sub Form1_KeyPress(sender As Object, e As KeyPressEventArgs) Handles MyBase.KeyPress
        Me.display_label.Text += e.KeyChar
    End Sub
End Class
