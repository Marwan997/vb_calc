﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form1))
        Me.display_label = New System.Windows.Forms.Label()
        Me.zero = New System.Windows.Forms.Button()
        Me.two = New System.Windows.Forms.Button()
        Me.one = New System.Windows.Forms.Button()
        Me.equal = New System.Windows.Forms.Button()
        Me.seven = New System.Windows.Forms.Button()
        Me.six = New System.Windows.Forms.Button()
        Me.five = New System.Windows.Forms.Button()
        Me.four = New System.Windows.Forms.Button()
        Me.eight = New System.Windows.Forms.Button()
        Me.nine = New System.Windows.Forms.Button()
        Me.divide = New System.Windows.Forms.Button()
        Me.clear = New System.Windows.Forms.Button()
        Me.three = New System.Windows.Forms.Button()
        Me.point = New System.Windows.Forms.Button()
        Me.plus = New System.Windows.Forms.Button()
        Me.minus = New System.Windows.Forms.Button()
        Me.multiply = New System.Windows.Forms.Button()
        Me.operator_label = New System.Windows.Forms.Label()
        Me.num1_label = New System.Windows.Forms.Label()
        Me.equal_label = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'display_label
        '
        Me.display_label.BackColor = System.Drawing.SystemColors.InactiveCaption
        Me.display_label.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.display_label.Font = New System.Drawing.Font("Microsoft YaHei UI", 26.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.display_label.Location = New System.Drawing.Point(15, 31)
        Me.display_label.Name = "display_label"
        Me.display_label.Size = New System.Drawing.Size(326, 51)
        Me.display_label.TabIndex = 0
        Me.display_label.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'zero
        '
        Me.zero.BackColor = System.Drawing.Color.Black
        Me.zero.Cursor = System.Windows.Forms.Cursors.Hand
        Me.zero.Font = New System.Drawing.Font("Microsoft Sans Serif", 24.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.zero.ForeColor = System.Drawing.Color.Gold
        Me.zero.Location = New System.Drawing.Point(15, 281)
        Me.zero.Name = "zero"
        Me.zero.Size = New System.Drawing.Size(160, 43)
        Me.zero.TabIndex = 1
        Me.zero.Text = "0"
        Me.zero.UseVisualStyleBackColor = False
        '
        'two
        '
        Me.two.BackColor = System.Drawing.Color.Black
        Me.two.Cursor = System.Windows.Forms.Cursors.Hand
        Me.two.Font = New System.Drawing.Font("Microsoft Sans Serif", 24.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.two.ForeColor = System.Drawing.Color.Gold
        Me.two.Location = New System.Drawing.Point(98, 232)
        Me.two.Name = "two"
        Me.two.Size = New System.Drawing.Size(77, 43)
        Me.two.TabIndex = 2
        Me.two.Text = "2"
        Me.two.UseVisualStyleBackColor = False
        '
        'one
        '
        Me.one.BackColor = System.Drawing.Color.Black
        Me.one.Cursor = System.Windows.Forms.Cursors.Hand
        Me.one.Font = New System.Drawing.Font("Microsoft Sans Serif", 24.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.one.ForeColor = System.Drawing.Color.Gold
        Me.one.Location = New System.Drawing.Point(15, 232)
        Me.one.Name = "one"
        Me.one.Size = New System.Drawing.Size(77, 43)
        Me.one.TabIndex = 3
        Me.one.Text = "1"
        Me.one.UseVisualStyleBackColor = False
        '
        'equal
        '
        Me.equal.BackColor = System.Drawing.Color.Black
        Me.equal.Cursor = System.Windows.Forms.Cursors.Hand
        Me.equal.Font = New System.Drawing.Font("Microsoft Sans Serif", 24.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.equal.ForeColor = System.Drawing.Color.Gold
        Me.equal.Location = New System.Drawing.Point(264, 232)
        Me.equal.Name = "equal"
        Me.equal.Size = New System.Drawing.Size(77, 92)
        Me.equal.TabIndex = 4
        Me.equal.Text = "="
        Me.equal.UseVisualStyleBackColor = False
        '
        'seven
        '
        Me.seven.BackColor = System.Drawing.Color.Black
        Me.seven.Cursor = System.Windows.Forms.Cursors.Hand
        Me.seven.Font = New System.Drawing.Font("Microsoft Sans Serif", 24.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.seven.ForeColor = System.Drawing.Color.Gold
        Me.seven.Location = New System.Drawing.Point(15, 134)
        Me.seven.Name = "seven"
        Me.seven.Size = New System.Drawing.Size(77, 43)
        Me.seven.TabIndex = 6
        Me.seven.Text = "7"
        Me.seven.UseVisualStyleBackColor = False
        '
        'six
        '
        Me.six.BackColor = System.Drawing.Color.Black
        Me.six.Cursor = System.Windows.Forms.Cursors.Hand
        Me.six.Font = New System.Drawing.Font("Microsoft Sans Serif", 24.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.six.ForeColor = System.Drawing.Color.Gold
        Me.six.Location = New System.Drawing.Point(181, 183)
        Me.six.Name = "six"
        Me.six.Size = New System.Drawing.Size(77, 43)
        Me.six.TabIndex = 7
        Me.six.Text = "6"
        Me.six.UseVisualStyleBackColor = False
        '
        'five
        '
        Me.five.BackColor = System.Drawing.Color.Black
        Me.five.Cursor = System.Windows.Forms.Cursors.Hand
        Me.five.Font = New System.Drawing.Font("Microsoft Sans Serif", 24.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.five.ForeColor = System.Drawing.Color.Gold
        Me.five.Location = New System.Drawing.Point(98, 183)
        Me.five.Name = "five"
        Me.five.Size = New System.Drawing.Size(77, 43)
        Me.five.TabIndex = 8
        Me.five.Text = "5"
        Me.five.UseVisualStyleBackColor = False
        '
        'four
        '
        Me.four.BackColor = System.Drawing.Color.Black
        Me.four.Cursor = System.Windows.Forms.Cursors.Hand
        Me.four.Font = New System.Drawing.Font("Microsoft Sans Serif", 24.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.four.ForeColor = System.Drawing.Color.Gold
        Me.four.Location = New System.Drawing.Point(15, 183)
        Me.four.Name = "four"
        Me.four.Size = New System.Drawing.Size(77, 43)
        Me.four.TabIndex = 9
        Me.four.Text = "4"
        Me.four.UseVisualStyleBackColor = False
        '
        'eight
        '
        Me.eight.BackColor = System.Drawing.Color.Black
        Me.eight.Cursor = System.Windows.Forms.Cursors.Hand
        Me.eight.Font = New System.Drawing.Font("Microsoft Sans Serif", 24.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.eight.ForeColor = System.Drawing.Color.Gold
        Me.eight.Location = New System.Drawing.Point(98, 134)
        Me.eight.Name = "eight"
        Me.eight.Size = New System.Drawing.Size(77, 43)
        Me.eight.TabIndex = 10
        Me.eight.Text = "8"
        Me.eight.UseVisualStyleBackColor = False
        '
        'nine
        '
        Me.nine.BackColor = System.Drawing.Color.Black
        Me.nine.Cursor = System.Windows.Forms.Cursors.Hand
        Me.nine.Font = New System.Drawing.Font("Microsoft Sans Serif", 24.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.nine.ForeColor = System.Drawing.Color.Gold
        Me.nine.Location = New System.Drawing.Point(181, 134)
        Me.nine.Name = "nine"
        Me.nine.Size = New System.Drawing.Size(77, 43)
        Me.nine.TabIndex = 11
        Me.nine.Text = "9"
        Me.nine.UseVisualStyleBackColor = False
        '
        'divide
        '
        Me.divide.BackColor = System.Drawing.Color.Black
        Me.divide.Cursor = System.Windows.Forms.Cursors.Hand
        Me.divide.Font = New System.Drawing.Font("Microsoft Sans Serif", 24.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.divide.ForeColor = System.Drawing.Color.Gold
        Me.divide.Location = New System.Drawing.Point(181, 85)
        Me.divide.Name = "divide"
        Me.divide.Size = New System.Drawing.Size(77, 43)
        Me.divide.TabIndex = 12
        Me.divide.Text = "/"
        Me.divide.UseVisualStyleBackColor = False
        '
        'clear
        '
        Me.clear.BackColor = System.Drawing.Color.Black
        Me.clear.Cursor = System.Windows.Forms.Cursors.Hand
        Me.clear.Font = New System.Drawing.Font("Microsoft Sans Serif", 24.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.clear.ForeColor = System.Drawing.Color.Gold
        Me.clear.Location = New System.Drawing.Point(12, 85)
        Me.clear.Name = "clear"
        Me.clear.Size = New System.Drawing.Size(163, 43)
        Me.clear.TabIndex = 14
        Me.clear.Text = "C"
        Me.clear.UseVisualStyleBackColor = False
        '
        'three
        '
        Me.three.BackColor = System.Drawing.Color.Black
        Me.three.Cursor = System.Windows.Forms.Cursors.Hand
        Me.three.Font = New System.Drawing.Font("Microsoft Sans Serif", 24.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.three.ForeColor = System.Drawing.Color.Gold
        Me.three.Location = New System.Drawing.Point(181, 232)
        Me.three.Name = "three"
        Me.three.Size = New System.Drawing.Size(77, 43)
        Me.three.TabIndex = 15
        Me.three.Text = "3"
        Me.three.UseVisualStyleBackColor = False
        '
        'point
        '
        Me.point.BackColor = System.Drawing.Color.Black
        Me.point.Cursor = System.Windows.Forms.Cursors.Hand
        Me.point.Font = New System.Drawing.Font("Microsoft Sans Serif", 24.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.point.ForeColor = System.Drawing.Color.Gold
        Me.point.Location = New System.Drawing.Point(181, 281)
        Me.point.Name = "point"
        Me.point.Size = New System.Drawing.Size(77, 43)
        Me.point.TabIndex = 16
        Me.point.Text = "."
        Me.point.UseVisualStyleBackColor = False
        '
        'plus
        '
        Me.plus.BackColor = System.Drawing.Color.Black
        Me.plus.Cursor = System.Windows.Forms.Cursors.Hand
        Me.plus.Font = New System.Drawing.Font("Microsoft Sans Serif", 24.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.plus.ForeColor = System.Drawing.Color.Gold
        Me.plus.Location = New System.Drawing.Point(264, 183)
        Me.plus.Name = "plus"
        Me.plus.Size = New System.Drawing.Size(77, 43)
        Me.plus.TabIndex = 17
        Me.plus.Text = "+"
        Me.plus.UseVisualStyleBackColor = False
        '
        'minus
        '
        Me.minus.BackColor = System.Drawing.Color.Black
        Me.minus.Cursor = System.Windows.Forms.Cursors.Hand
        Me.minus.Font = New System.Drawing.Font("Microsoft Sans Serif", 24.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.minus.ForeColor = System.Drawing.Color.Gold
        Me.minus.Location = New System.Drawing.Point(264, 134)
        Me.minus.Name = "minus"
        Me.minus.Size = New System.Drawing.Size(77, 43)
        Me.minus.TabIndex = 18
        Me.minus.Text = "-"
        Me.minus.UseVisualStyleBackColor = False
        '
        'multiply
        '
        Me.multiply.BackColor = System.Drawing.Color.Black
        Me.multiply.Cursor = System.Windows.Forms.Cursors.Hand
        Me.multiply.Font = New System.Drawing.Font("Microsoft Sans Serif", 24.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.multiply.ForeColor = System.Drawing.Color.Gold
        Me.multiply.Location = New System.Drawing.Point(264, 85)
        Me.multiply.Name = "multiply"
        Me.multiply.Size = New System.Drawing.Size(77, 43)
        Me.multiply.TabIndex = 19
        Me.multiply.Text = "X"
        Me.multiply.UseVisualStyleBackColor = False
        '
        'operator_label
        '
        Me.operator_label.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.operator_label.ForeColor = System.Drawing.SystemColors.AppWorkspace
        Me.operator_label.Location = New System.Drawing.Point(304, 3)
        Me.operator_label.Name = "operator_label"
        Me.operator_label.Size = New System.Drawing.Size(37, 28)
        Me.operator_label.TabIndex = 20
        Me.operator_label.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'num1_label
        '
        Me.num1_label.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.num1_label.ForeColor = System.Drawing.SystemColors.AppWorkspace
        Me.num1_label.Location = New System.Drawing.Point(15, 3)
        Me.num1_label.Name = "num1_label"
        Me.num1_label.Size = New System.Drawing.Size(283, 28)
        Me.num1_label.TabIndex = 22
        Me.num1_label.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'equal_label
        '
        Me.equal_label.BackColor = System.Drawing.Color.NavajoWhite
        Me.equal_label.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.equal_label.Font = New System.Drawing.Font("Microsoft YaHei UI", 26.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.equal_label.Location = New System.Drawing.Point(45, 337)
        Me.equal_label.Name = "equal_label"
        Me.equal_label.Size = New System.Drawing.Size(293, 51)
        Me.equal_label.TabIndex = 23
        Me.equal_label.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Label2
        '
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Label2.Location = New System.Drawing.Point(2, 337)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(37, 45)
        Me.Label2.TabIndex = 24
        Me.Label2.Text = "="
        Me.Label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.ControlDarkDark
        Me.ClientSize = New System.Drawing.Size(353, 397)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.equal_label)
        Me.Controls.Add(Me.num1_label)
        Me.Controls.Add(Me.operator_label)
        Me.Controls.Add(Me.multiply)
        Me.Controls.Add(Me.minus)
        Me.Controls.Add(Me.plus)
        Me.Controls.Add(Me.point)
        Me.Controls.Add(Me.three)
        Me.Controls.Add(Me.clear)
        Me.Controls.Add(Me.divide)
        Me.Controls.Add(Me.nine)
        Me.Controls.Add(Me.eight)
        Me.Controls.Add(Me.four)
        Me.Controls.Add(Me.five)
        Me.Controls.Add(Me.six)
        Me.Controls.Add(Me.seven)
        Me.Controls.Add(Me.equal)
        Me.Controls.Add(Me.one)
        Me.Controls.Add(Me.two)
        Me.Controls.Add(Me.zero)
        Me.Controls.Add(Me.display_label)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "Form1"
        Me.Text = "Calculator"
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents display_label As Label
    Friend WithEvents zero As Button
    Friend WithEvents two As Button
    Friend WithEvents one As Button
    Friend WithEvents equal As Button
    Friend WithEvents seven As Button
    Friend WithEvents six As Button
    Friend WithEvents five As Button
    Friend WithEvents four As Button
    Friend WithEvents eight As Button
    Friend WithEvents nine As Button
    Friend WithEvents divide As Button
    Friend WithEvents clear As Button
    Friend WithEvents three As Button
    Friend WithEvents point As Button
    Friend WithEvents plus As Button
    Friend WithEvents minus As Button
    Friend WithEvents multiply As Button
    Friend WithEvents operator_label As Label
    Friend WithEvents num1_label As Label
    Friend WithEvents equal_label As Label
    Friend WithEvents Label2 As Label
End Class
